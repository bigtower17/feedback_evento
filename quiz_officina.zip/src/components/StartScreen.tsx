import React from 'react';

interface StartScreenProps {
  onStartQuiz: () => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStartQuiz }) => {
  return (
    <div className="text-center animate-fadeIn max-w-md w-full">
      <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">
        Benvenuto al Test del Gommista!
      </h1>
      <button
        onClick={onStartQuiz}
        className="bg-custom-green text-white font-semibold py-3 px-6 rounded-lg hover:bg-custom-green-dark transition-colors hover:pulse"
      >
        Inizia il quiz
      </button>
    </div>
  );
};

export default StartScreen;