import React, { useState } from 'react';
import logo from '../assets/images/logo.svg'; // Import the logo image

interface StartScreenProps {
  onStartQuiz: (quizId?: string) => void; // Optional parameter for dynamic quiz start
  headingText?: string; // Dynamic heading text
  buttonText?: string; // Dynamic button text
  loading?: boolean; // Show loading state
  customStyles?: string; // Custom styles for container
}

const StartScreen: React.FC<StartScreenProps> = ({
  onStartQuiz,
  headingText = "Benvenuto al Test del Gommista!", // Default heading
  buttonText = "Inizia il quiz", // Default button text
  loading = false, // Default to not loading
  customStyles = "", // Default empty styles
}) => {
  const [isLoading, setIsLoading] = useState<boolean>(loading);

  const handleStartClick = () => {
    setIsLoading(true); // Set loading state
    onStartQuiz("quizId123"); // Pass dynamic data if needed
  };

  return (
    <div
      className={`relative text-center animate-fadeIn max-w-md w-full mt-60 md:mt-24 ${customStyles}`}
    >
      {/* Pseudo-element for background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${logo})`, // Set the background image
          opacity: 0.05, // Set transparency to 10%
          zIndex: -1, // Position it behind the content
        }}
      />
      
      <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">
        {headingText}
      </h1>
      <button
        onClick={handleStartClick}
        className="bg-custom-green text-white font-semibold py-3 px-6 rounded-lg hover:bg-custom-green-dark transition-colors hover:pulse"
        disabled={isLoading} // Disable button while loading
      >
        {isLoading ? (
          <span className="loader">Caricamento...</span> // Show loading spinner or text
        ) : (
          buttonText
        )}
      </button>
    </div>
  );
};

export default StartScreen;
