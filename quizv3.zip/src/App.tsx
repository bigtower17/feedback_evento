// App.tsx
import React, { useState } from 'react';
import StartScreen from './components/StartScreen';
import QuestionCard from './components/QuestionCard';
import ResultScreen from './components/ResultScreen';
import Header from './components/Header';
import Footer from './components/Footer';
import { questions } from './data/questions';
import './style.css';

const App: React.FC = () => {
  const [startQuiz, setStartQuiz] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);

  const handleStartQuiz = () => {
    setStartQuiz(true);
  };

  const handleAnswer = (points: number) => {
    setScore(prevScore => {
      const newScore = prevScore + points;
      console.log(`Score updated: ${newScore}, Question Index: ${currentQuestionIndex}`);
      return newScore;
    });
    setCurrentQuestionIndex(prevIndex => {
      const newIndex = prevIndex + 1;
      console.log(`Moving to question index: ${newIndex}`);
      return newIndex;
    });
  };

  const handleRestart = () => {
    setStartQuiz(false);
    setCurrentQuestionIndex(0);
    setScore(0);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      <Header onHome={handleRestart} showHomeButton={startQuiz} />
      <main className="flex-grow flex items-start justify-center px-4 pt-20 pb-32">
        {!startQuiz && <StartScreen onStartQuiz={handleStartQuiz} />}
        {startQuiz && currentQuestionIndex < questions.length && (
          <QuestionCard
            question={questions[currentQuestionIndex]}
            onAnswer={handleAnswer}
          />
        )}
        {startQuiz && currentQuestionIndex >= questions.length && (
          <div className="w-full max-w-md">
            <ResultScreen score={score} />
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default App;