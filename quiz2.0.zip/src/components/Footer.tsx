import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white py-6 w-full fixed bottom-0 left-0">
      <div className="container mx-auto flex flex-col items-center">
        <p className="text-sm">
          © {new Date().getFullYear()} OfficinaInCloud. Tutti i diritti riservati.
        </p>
        <a
          href="http://www.officinaincloud.it"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-400 hover:text-gray-700 mt-2 transition-colors"
        >
          Visita il nostro sito
        </a>
      </div>
    </footer>
  );
};

export default Footer;